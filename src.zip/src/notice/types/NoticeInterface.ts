export interface NoticeInterface {
    id: number;
    titulo: string;
    participante: string;
    fecha_proyecto: string;
    imagen: string;
    descripcion_corta: string;
    descripcion_completa: string;
}