export interface MenuInterface {
    id: number;
    title: string;
    description: string;
    route: string;
    icon?: string;
}